import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Carlos2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Carlos2 extends Actor
{
    /**
     * Act - do whatever the Carlos2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    
    private int vSpeed = 0;
    private int acc = 1;
    private int jumpHeight= -12;
    
    public void act()
    {
        moveAround();
        checkFalling();
        
    }
    
    private void fall(){
        setLocation(getX(), getY() + vSpeed);
        vSpeed = vSpeed + acc;
    }
    
    public void moveAround(){
        if(Greenfoot.isKeyDown("right")){
            move(6);
        }
        
        if(Greenfoot.isKeyDown("left")){
            move(-6);
        }
        if(Greenfoot.isKeyDown("space") && onGround()== true){
            vSpeed = jumpHeight;
            fall();
        }
    }
    
    boolean onGround(){
        Actor under = getOneObjectAtOffset(0, getImage().getHeight()/2, Ground.class);
        return under != null; 
    }
    
    public void checkFalling(){
        if (onGround()== false){
            fall();
        }
        if (onGround()== true){
            vSpeed = 0;
        }
    }
    
    public void checkVoid(){
       if(isAtEdge()){
           Greenfoot.setWorld(new Hoyo());
       }
    }
}
