import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Hoyo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Hoyo extends World
{
    SimpleTimer tim = new SimpleTimer();
    Counter timeCount = new Counter();
    int start = 0;
    /**
     * Constructor for objects of class Hoyo.
     * 
     */
    public Hoyo()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1000, 400, 1); 
        addObject(timeCount, getWidth()/2, getHeight()/2);
        timeCount.setValue(10);
        prepare();
    }
    
    public void act(){
        start = 1;
        if (start == 1){
            if (tim.millisElapsed() > 1000){
             timeCount.add(-1);   
             tim.mark();
            }
        }
        
        if (timeCount.getValue() < 0){
            Greenfoot.setWorld(new Hoyo());
        }
        
    }

 
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Ground ground = new Ground();
        addObject(ground,778,337);
        Ground ground2 = new Ground();
        addObject(ground2,351,318);
        ground.setLocation(808,345);
        ground2.setLocation(570,360);
        Ground ground3 = new Ground();
        addObject(ground3,28,362);
        Ground ground4 = new Ground();
        addObject(ground4,163,282);
        ground4.setLocation(287,296);
        ground4.setLocation(297,296);
        Ground ground5 = new Ground();
        addObject(ground5,760,130);
        ground3.setLocation(140,224);
        ground3.setLocation(270,148);
        removeObject(ground3);
        ground4.setLocation(207,202);
        removeObject(ground);
        ground2.setLocation(739,345);
        ground4.setLocation(416,369);
        ground5.setLocation(436,138);
        Carlos2 carlos2 = new Carlos2();
        addObject(carlos2,502,52);
        ground4.setLocation(372,328);
        ground4.setLocation(384,324);
        ground2.setLocation(739,280);
        ground4.setLocation(381,315);
        ground5.setLocation(391,116);
        ground5.setLocation(328,111);
        ground2.setLocation(659,235);
        CIT cIT = new CIT();
        addObject(cIT,167,46);
        ground4.setLocation(303,336);
        ground2.setLocation(540,289);
        ground2.setLocation(776,226);
        ground4.setLocation(96,357);
        ground2.setLocation(236,324);
        ground5.setLocation(444,301);
        Ground ground6 = new Ground();
        addObject(ground6,428,219);
        ground6.setLocation(429,234);
        Ground ground7 = new Ground();
        addObject(ground7,649,230);
        ground7.setLocation(617,237);
        Ground ground8 = new Ground();
        addObject(ground8,871,249);
        ground8.setLocation(804,235);
        Ground ground9 = new Ground();
        addObject(ground9,805,162);
        ground9.setLocation(811,176);
        Ground ground10 = new Ground();
        addObject(ground10,799,92);
        ground10.setLocation(804,106);
        Ground ground11 = new Ground();
        addObject(ground11,612,111);
        ground11.setLocation(615,116);
        cIT.setLocation(604,59);
        carlos2.setLocation(79,310);
    }
}
