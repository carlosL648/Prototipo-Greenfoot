import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Void here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Void extends Actor
{
    public Void(){
        getImage().scale(getImage().getWidth()*10,getImage().getHeight()/3);
    }
    
    /**
     * Act - do whatever the Void wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
